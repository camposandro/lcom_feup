var searchData=
[
  ['v_5fres',['V_RES',['../group__vg.html#gaac2466862bcfc18231c38fe1eacc22e3',1,'video_gr.h']]],
  ['vbe_2ec',['vbe.c',['../vbe_8c.html',1,'']]],
  ['vbe_2eh',['vbe.h',['../vbe_8h.html',1,'']]],
  ['vbe_5fget_5fmode_5finfo',['vbe_get_mode_info',['../vbe_8c.html#a4ef3234e41f2050bc094a22049b69e45',1,'vbe_get_mode_info(unsigned short mode, vbe_mode_info_t *vmi_p):&#160;vbe.c'],['../vbe_8h.html#a4ef3234e41f2050bc094a22049b69e45',1,'vbe_get_mode_info(unsigned short mode, vbe_mode_info_t *vmi_p):&#160;vbe.c']]],
  ['video_5fgraphics',['Video_Graphics',['../group__vg.html',1,'']]],
  ['vg_5fclear',['vg_clear',['../group__vg.html#gae73efbc5eb5fa85cab0358d0e4de8809',1,'vg_clear():&#160;video_gr.c'],['../group__vg.html#gae73efbc5eb5fa85cab0358d0e4de8809',1,'vg_clear():&#160;video_gr.c']]],
  ['vg_5fcopy',['vg_copy',['../group__vg.html#ga6a48d2eaa7f116fca3dde151edee4f98',1,'vg_copy():&#160;video_gr.c'],['../group__vg.html#ga6a48d2eaa7f116fca3dde151edee4f98',1,'vg_copy():&#160;video_gr.c']]],
  ['vg_5fcursor_5fclear',['vg_cursor_clear',['../group__vg.html#gad4b3d412aae08ead88d0a57351363ccc',1,'vg_cursor_clear():&#160;video_gr.c'],['../group__vg.html#gad4b3d412aae08ead88d0a57351363ccc',1,'vg_cursor_clear():&#160;video_gr.c']]],
  ['vg_5fdrawrect',['vg_drawRect',['../group__vg.html#ga33f05e70b2612bd4d6bde66ca0c9dd17',1,'vg_drawRect(unsigned int start_x, unsigned int start_y, unsigned int width, unsigned int height, unsigned int color):&#160;video_gr.c'],['../group__vg.html#ga33f05e70b2612bd4d6bde66ca0c9dd17',1,'vg_drawRect(unsigned int start_x, unsigned int start_y, unsigned int width, unsigned int height, unsigned int color):&#160;video_gr.c']]],
  ['vg_5fexit',['vg_exit',['../group__vg.html#ga42f593e6656f1a978315aff02b1bcebf',1,'vg_exit():&#160;video_gr.c'],['../group__vg.html#ga42f593e6656f1a978315aff02b1bcebf',1,'vg_exit(void):&#160;video_gr.c']]],
  ['vg_5ffree',['vg_free',['../group__vg.html#ga71250a7e4fc5b89a38e76c7d68f3a5fc',1,'vg_free():&#160;video_gr.c'],['../group__vg.html#ga71250a7e4fc5b89a38e76c7d68f3a5fc',1,'vg_free():&#160;video_gr.c']]],
  ['vg_5finit',['vg_init',['../group__vg.html#gacef21667c79365d57a084bed994c2189',1,'vg_init(unsigned short mode):&#160;video_gr.c'],['../group__vg.html#gacef21667c79365d57a084bed994c2189',1,'vg_init(unsigned short mode):&#160;video_gr.c']]],
  ['vg_5fpng',['vg_png',['../group__vg.html#ga894c38c5521f2bea444963376e3fa07a',1,'vg_png(unsigned char *image, int width, int height, uint16_t start_x, uint16_t start_y):&#160;video_gr.c'],['../group__vg.html#ga894c38c5521f2bea444963376e3fa07a',1,'vg_png(unsigned char *image, int width, int height, uint16_t start_x, uint16_t start_y):&#160;video_gr.c']]],
  ['vg_5fprint_5fborders',['vg_print_borders',['../group__vg.html#ga6d287d99136ee1ff47424554ab754ad7',1,'vg_print_borders():&#160;video_gr.c'],['../group__vg.html#ga6d287d99136ee1ff47424554ab754ad7',1,'vg_print_borders():&#160;video_gr.c']]],
  ['vg_5fsnake_5fclear',['vg_snake_clear',['../group__vg.html#ga3f89b156c83bd5928545a00d1d2ff6df',1,'vg_snake_clear():&#160;video_gr.c'],['../group__vg.html#ga3f89b156c83bd5928545a00d1d2ff6df',1,'vg_snake_clear():&#160;video_gr.c']]],
  ['vg_5ftile',['vg_tile',['../group__vg.html#gad3c7f369776e7436bad8383258715ae6',1,'vg_tile(unsigned char *image, char letter, int width, int height, uint16_t start_x, uint16_t start_y):&#160;video_gr.c'],['../group__vg.html#gad3c7f369776e7436bad8383258715ae6',1,'vg_tile(unsigned char *image, char letter, int width, int height, uint16_t start_x, uint16_t start_y):&#160;video_gr.c']]],
  ['victory_5fscreen',['victory_screen',['../group__Game.html#ga8f2b1f99e61110872c3fd0bc6418bad9',1,'victory_screen(Menu *menu, char *winner):&#160;game.c'],['../group__Game.html#ga8f2b1f99e61110872c3fd0bc6418bad9',1,'victory_screen(Menu *menu, char *winner):&#160;game.c']]],
  ['video_5fgr_2ec',['video_gr.c',['../video__gr_8c.html',1,'']]],
  ['video_5fgr_2eh',['video_gr.h',['../video__gr_8h.html',1,'']]],
  ['virtual',['virtual',['../group__lmlib.html#ga4de93144fb3ffbceb9bd1f3009d6d98c',1,'mmap_t']]]
];
