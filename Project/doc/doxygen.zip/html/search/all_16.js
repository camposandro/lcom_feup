var searchData=
[
  ['x',['x',['../structcoord__t.html#a080c2dfe195dae7be02cce3d6b026f25',1,'coord_t']]],
  ['xcharsize',['XCharSize',['../struct____attribute____.html#acac41a300563737d7849a92cd1d5c10b',1,'__attribute__']]],
  ['xov',['XOV',['../group__i8042.html#gae1edb2816b16ab2047d8afb9fab347e8',1,'i8042.h']]],
  ['xresolution',['XResolution',['../struct____attribute____.html#abe48e2b29aa99e813a1447d22711f4f4',1,'__attribute__']]],
  ['xsign',['XSIGN',['../group__i8042.html#ga22a4873e9adebfc22650f6776375cce6',1,'i8042.h']]]
];
