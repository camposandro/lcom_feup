var searchData=
[
  ['y',['y',['../structcoord__t.html#a70fc641a7428fa745a649e0bd5f75e2c',1,'coord_t']]],
  ['ycharsize',['YCharSize',['../struct____attribute____.html#acb93d86860efea5c87e3c2950f39123e',1,'__attribute__']]],
  ['yov',['YOV',['../group__i8042.html#ga77fc5a1075f325b5f67beb9359eb9149',1,'i8042.h']]],
  ['yresolution',['YResolution',['../struct____attribute____.html#aa91385451d974d9c33978062e22d39e2',1,'__attribute__']]],
  ['ysign',['YSIGN',['../group__i8042.html#gaf4bf97e57d9aadf00d2ec881727cccef',1,'i8042.h']]]
];
