var searchData=
[
  ['banksize',['BankSize',['../struct____attribute____.html#aa1307567cbc12f9c5c724b7457be14ad',1,'__attribute__']]],
  ['bg_5fcolor',['BG_COLOR',['../group__vg.html#gae7ed5ea1d43fb2b71b3eaea2397fb5ca',1,'video_gr.h']]],
  ['bit',['BIT',['../group__i8042.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;i8042.h'],['../group__i8254.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;i8254.h'],['../group__vg.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;video_gr.h']]],
  ['bitsperpixel',['BitsPerPixel',['../struct____attribute____.html#abd9c59af53589a54188bb57ada5c5f26',1,'__attribute__']]],
  ['black',['BLACK',['../group__vg.html#ga7b3b25cba33b07c303f3060fe41887f6',1,'video_gr.h']]],
  ['blue',['BLUE',['../group__vg.html#ga79d10e672abb49ad63eeaa8aaef57c38',1,'video_gr.h']]],
  ['bluefieldposition',['BlueFieldPosition',['../struct____attribute____.html#ada852d5ed926757d24b5038a38e6292c',1,'__attribute__']]],
  ['bluemasksize',['BlueMaskSize',['../struct____attribute____.html#ab5967602a79dcb7f0061195ffdaaa47a',1,'__attribute__']]],
  ['bnknumberofimagepages',['BnkNumberOfImagePages',['../struct____attribute____.html#ad5820084f2b821b85a635df8394f0d9e',1,'__attribute__']]],
  ['border_5fcolor',['BORDER_COLOR',['../group__vg.html#ga966901ace2cf6cba3fc9cec310150860',1,'video_gr.h']]],
  ['border_5fsize',['BORDER_SIZE',['../group__Game.html#ga83b9df0c7acc5653665d1efd14d1a65b',1,'game.h']]],
  ['bytesperscanline',['BytesPerScanLine',['../struct____attribute____.html#a3c9eb4b107ecee102c6e63f9054ede06',1,'__attribute__']]]
];
