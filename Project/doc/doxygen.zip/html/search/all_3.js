var searchData=
[
  ['clean_5fcursor',['clean_cursor',['../group__Game.html#ga5342bd1891e166d267a48b4df65bd9f1',1,'clean_cursor(Game *game, Word word, int letter_index):&#160;game.c'],['../group__Game.html#ga5342bd1891e166d267a48b4df65bd9f1',1,'clean_cursor(Game *game, Word word, int letter_index):&#160;game.c']]],
  ['color',['color',['../structSnake.html#a5e850aff3ef56c4e5c100bab14128159',1,'Snake']]],
  ['coord',['coord',['../structCursor.html#a49d8817a50cbd157c5d23b1447f77dd9',1,'Cursor::coord()'],['../structSnake.html#a00fefcc16a255f05ae59a63f2c30b0b6',1,'Snake::coord()']]],
  ['coord_5fkbd',['coord_kbd',['../structWord.html#a5e5828800957d6c9080ae77c12189626',1,'Word']]],
  ['coord_5fmouse',['coord_mouse',['../structWord.html#a850023044f54380e85ae45bb0d00cdda',1,'Word']]],
  ['coord_5ft',['coord_t',['../structcoord__t.html',1,'coord_t'],['../group__Game.html#ga437098a5ab89e0e83c986d7be2a3ca4f',1,'coord_t():&#160;game.h']]],
  ['current_5fbackground',['current_background',['../structMenu.html#ad151a12bee66177321512f2a8f8f39a0',1,'Menu']]],
  ['current_5fstate',['current_state',['../structGame.html#a6888947fb29f84c9f07f6a5c5598345d',1,'Game']]],
  ['cursor',['Cursor',['../structCursor.html',1,'Cursor'],['../structGame.html#a8b78c9e4ad2d603ec2c57404def327fd',1,'Game::cursor()'],['../group__Game.html#gac7c9687307ea23b41e53083470448580',1,'Cursor():&#160;game.h']]],
  ['cursor_5fimgpath',['CURSOR_IMGPATH',['../group__Game.html#gab35196890460013e60f83032541c5efa',1,'game.h']]],
  ['cursor_5fvict_5fimgpath',['CURSOR_VICT_IMGPATH',['../group__Game.html#ga9fcb7dc2ba9db8a4a980ecd5ff3e9a33',1,'game.h']]],
  ['cursor_5fvictory',['cursor_victory',['../structMenu.html#ae0d6ba943775a3166dc095afaddc4389',1,'Menu']]]
];
