var searchData=
[
  ['d_5fkey',['D_KEY',['../group__Game.html#ga23c8dc1c6696b91ba6b96f2dca53b7ba',1,'game.h']]],
  ['destroy_5fcursor',['destroy_cursor',['../group__Game.html#ga703c262b2001b4ee8aadfadd87baae71',1,'destroy_cursor(Cursor *cursor):&#160;game.c'],['../group__Game.html#ga703c262b2001b4ee8aadfadd87baae71',1,'destroy_cursor(Cursor *cursor):&#160;game.c']]],
  ['destroy_5ffont',['destroy_font',['../group__Game.html#ga88284a4a5557c8b2141ff7fd2ef68752',1,'destroy_font(Font *font):&#160;game.c'],['../group__Game.html#ga88284a4a5557c8b2141ff7fd2ef68752',1,'destroy_font(Font *font):&#160;game.c']]],
  ['destroy_5fmenu',['destroy_menu',['../group__Game.html#ga252144e4c8068bdc067d07ad3e48dacc',1,'destroy_menu(Menu *menu):&#160;game.c'],['../group__Game.html#ga252144e4c8068bdc067d07ad3e48dacc',1,'destroy_menu(Menu *menu):&#160;game.c']]],
  ['destroy_5fsnake',['destroy_snake',['../group__Game.html#ga234a09c90544ea458b45084c469dabd8',1,'destroy_snake(Snake *snake):&#160;game.c'],['../group__Game.html#ga234a09c90544ea458b45084c469dabd8',1,'destroy_snake(Snake *snake):&#160;game.c']]],
  ['destroy_5fwords',['destroy_words',['../group__Game.html#gadc6512b6d74091c603ab8343d5eccfe4',1,'destroy_words(Word *words):&#160;game.c'],['../group__Game.html#gadc6512b6d74091c603ab8343d5eccfe4',1,'destroy_words(Word *words):&#160;game.c']]],
  ['directcolormodeinfo',['DirectColorModeInfo',['../struct____attribute____.html#a35fb3e1fc0dc9924bc52977b3a234f9f',1,'__attribute__']]],
  ['disable_5fmouse',['DISABLE_MOUSE',['../group__i8042.html#ga12d3b0abea66d191d47fe6860e58865e',1,'i8042.h']]],
  ['draw_5fpixel',['draw_pixel',['../group__vg.html#ga18107cedb98361dc0fa1f2680d2e6536',1,'draw_pixel(uint16_t x, uint16_t y, uint32_t color):&#160;video_gr.c'],['../group__vg.html#ga18107cedb98361dc0fa1f2680d2e6536',1,'draw_pixel(uint16_t x, uint16_t y, uint32_t color):&#160;video_gr.c']]]
];
