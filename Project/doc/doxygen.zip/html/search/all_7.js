var searchData=
[
  ['g_5fbyte',['g_byte',['../game_8c.html#abf11673f10aa470966a48362eb0c8898',1,'game.c']]],
  ['g_5fcount_5fbytes',['g_count_bytes',['../game_8c.html#acaf018bd2b60865897b5b8c305fe29ad',1,'game.c']]],
  ['g_5fhookid_5fkbd',['g_hookid_kbd',['../game_8c.html#aeb67c462bf58048b56191a4ebad6b9d2',1,'game.c']]],
  ['g_5fhookid_5fmouse',['g_hookid_mouse',['../game_8c.html#aa78c5226f15bcc4e59160f10133d5b72',1,'game.c']]],
  ['g_5fhookid_5ftimer',['g_hookid_timer',['../game_8c.html#ad0f40f6a67c63d7dcdf067379e3c6385',1,'game.c']]],
  ['g_5fpacket',['g_packet',['../game_8c.html#af61847bbeec266c44ff81997a3346520',1,'game.c']]],
  ['g_5fscancode',['g_scancode',['../game_8c.html#af282f760ae35d62384f5ee8ab352d7b2',1,'game.c']]],
  ['game',['Game',['../structGame.html',1,'Game'],['../group__Game.html#ga97f6b77516244ef6d003daaaa9849040',1,'Game():&#160;game.h'],['../group__Game.html',1,'(Global Namespace)']]],
  ['game_2ec',['game.c',['../game_8c.html',1,'']]],
  ['game_2eh',['game.h',['../game_8h.html',1,'']]],
  ['game_5fevent_5ft',['game_event_t',['../group__Game.html#ga03e39b401e368d6d487cf3d5a2426742',1,'game.h']]],
  ['game_5fstate_5ft',['game_state_t',['../group__Game.html#ga4edce1ca040716922b6e4a79be4e414d',1,'game.h']]],
  ['grass_5fcolor',['GRASS_COLOR',['../group__vg.html#gae53addc3a312ada6cffbe08bd2787b27',1,'video_gr.h']]],
  ['green',['GREEN',['../group__vg.html#gacfbc006ea433ad708fdee3e82996e721',1,'video_gr.h']]],
  ['greenfieldposition',['GreenFieldPosition',['../struct____attribute____.html#a44aab7c8026a131654e079837a95ba2b',1,'__attribute__']]],
  ['greenmasksize',['GreenMaskSize',['../struct____attribute____.html#af69ef188a0f5d526ecd5f25a8d6336e3',1,'__attribute__']]]
];
