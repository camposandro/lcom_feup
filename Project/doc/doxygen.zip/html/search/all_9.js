var searchData=
[
  ['i8042',['i8042',['../group__i8042.html',1,'']]],
  ['i8042_2eh',['i8042.h',['../i8042_8h.html',1,'']]],
  ['i8254',['i8254',['../group__i8254.html',1,'']]],
  ['i8254_2eh',['i8254.h',['../i8254_8h.html',1,'']]],
  ['ibf',['IBF',['../group__i8042.html#ga3c48b10907056351582baf9f6478598e',1,'i8042.h']]],
  ['image',['image',['../structCursor.html#ac3f133f7258e3e2737c65d90803754b1',1,'Cursor']]],
  ['in_5fbuf',['IN_BUF',['../group__i8042.html#ga783be5698cf07b1daaf126ef89c19063',1,'i8042.h']]],
  ['init',['INIT',['../group__Game.html#gga4edce1ca040716922b6e4a79be4e414da0cb1b2c6a7db1f1084886c98909a3f36',1,'game.h']]],
  ['initialize_5fcursor',['initialize_cursor',['../group__Game.html#ga66342a00d38ae5b5b88cb493e7ef5506',1,'initialize_cursor():&#160;game.c'],['../group__Game.html#ga66342a00d38ae5b5b88cb493e7ef5506',1,'initialize_cursor():&#160;game.c']]],
  ['initialize_5ffont',['initialize_font',['../group__Game.html#gaecf9df8b0ea4c8b945bdf317eb1727ed',1,'initialize_font():&#160;game.c'],['../group__Game.html#gaecf9df8b0ea4c8b945bdf317eb1727ed',1,'initialize_font():&#160;game.c']]],
  ['initialize_5fmenu',['initialize_menu',['../group__Game.html#gace95ea7511f280d458264b13b1bb2f53',1,'initialize_menu():&#160;game.c'],['../group__Game.html#gace95ea7511f280d458264b13b1bb2f53',1,'initialize_menu():&#160;game.c']]],
  ['initialize_5fsnake',['initialize_snake',['../group__Game.html#gaea112ca02fdfd2503ba06178e89d106a',1,'initialize_snake():&#160;game.c'],['../group__Game.html#gaea112ca02fdfd2503ba06178e89d106a',1,'initialize_snake():&#160;game.c']]]
];
