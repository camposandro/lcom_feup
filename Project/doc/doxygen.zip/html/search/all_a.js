var searchData=
[
  ['kbc_5fcmd_5freg',['KBC_CMD_REG',['../group__i8042.html#ga6d57c7927a10f638c83046b52c8caac9',1,'i8042.h']]],
  ['kbd_2ec',['kbd.c',['../kbd_8c.html',1,'']]],
  ['kbd_2eh',['kbd.h',['../kbd_8h.html',1,'']]],
  ['kbd_5fasm_5fhandler',['kbd_asm_handler',['../group__Keyboard.html#ga59cb8885a1fad1904901095686f2657a',1,'kbd.h']]],
  ['kbd_5firq',['KBD_IRQ',['../group__i8042.html#ga5c1072213ce8d8cd43628c4319ae0391',1,'i8042.h']]],
  ['kbd_5fsubscribe_5fint',['kbd_subscribe_int',['../group__Keyboard.html#gaef2c8ccb6cd2ba3cff387bd31d9d08b7',1,'kbd_subscribe_int(int *g_hookid_kbd):&#160;kbd.c'],['../group__Keyboard.html#gaef2c8ccb6cd2ba3cff387bd31d9d08b7',1,'kbd_subscribe_int(int *g_hookid_kbd):&#160;kbd.c']]],
  ['kbd_5funsubscribe_5fint',['kbd_unsubscribe_int',['../group__Keyboard.html#gaea06ebd72a5660d2edf7c7b658531762',1,'kbd_unsubscribe_int(int *g_hookid_kbd):&#160;kbd.c'],['../group__Keyboard.html#gaea06ebd72a5660d2edf7c7b658531762',1,'kbd_unsubscribe_int(int *g_hookid_kbd):&#160;kbd.c']]],
  ['key',['key',['../structSnake.html#a66767d3c0c878e5a911a56dad9edc043',1,'Snake']]],
  ['keyboard',['Keyboard',['../group__Keyboard.html',1,'']]]
];
