var searchData=
[
  ['obf',['OBF',['../group__i8042.html#ga45967c9e25447ba853cf6fb4ac545fe6',1,'i8042.h']]],
  ['out_5fbuf',['OUT_BUF',['../group__i8042.html#gacfb42dde389e8ca36ab267002fbf5c6a',1,'i8042.h']]],
  ['outbuff_5ftrash',['outbuff_trash',['../game_8c.html#ae29cb2d9424b27b8a9ee3983649e0ce9',1,'game.c']]]
];
