var searchData=
[
  ['coord_5ft',['coord_t',['../structcoord__t.html',1,'']]],
  ['cursor',['Cursor',['../structCursor.html',1,'']]]
];
