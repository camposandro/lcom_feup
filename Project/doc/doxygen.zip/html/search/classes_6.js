var searchData=
[
  ['word',['Word',['../structWord.html',1,'']]]
];
