var searchData=
[
  ['game_5fevent_5ft',['game_event_t',['../group__Game.html#ga03e39b401e368d6d487cf3d5a2426742',1,'game.h']]],
  ['game_5fstate_5ft',['game_state_t',['../group__Game.html#ga4edce1ca040716922b6e4a79be4e414d',1,'game.h']]]
];
