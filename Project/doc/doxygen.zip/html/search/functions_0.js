var searchData=
[
  ['clean_5fcursor',['clean_cursor',['../group__Game.html#ga5342bd1891e166d267a48b4df65bd9f1',1,'clean_cursor(Game *game, Word word, int letter_index):&#160;game.c'],['../group__Game.html#ga5342bd1891e166d267a48b4df65bd9f1',1,'clean_cursor(Game *game, Word word, int letter_index):&#160;game.c']]]
];
