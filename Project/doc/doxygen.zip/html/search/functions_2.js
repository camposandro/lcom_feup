var searchData=
[
  ['handle_5fevent',['handle_event',['../group__Game.html#ga363b542222ad8cc4f7c4fe1b33f4729c',1,'handle_event(Game *game, game_event_t game_event):&#160;game.c'],['../group__Game.html#ga363b542222ad8cc4f7c4fe1b33f4729c',1,'handle_event(Game *game, game_event_t game_event):&#160;game.c']]]
];
