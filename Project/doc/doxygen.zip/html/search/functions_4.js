var searchData=
[
  ['kbd_5fasm_5fhandler',['kbd_asm_handler',['../group__Keyboard.html#ga59cb8885a1fad1904901095686f2657a',1,'kbd.h']]],
  ['kbd_5fsubscribe_5fint',['kbd_subscribe_int',['../group__Keyboard.html#gaef2c8ccb6cd2ba3cff387bd31d9d08b7',1,'kbd_subscribe_int(int *g_hookid_kbd):&#160;kbd.c'],['../group__Keyboard.html#gaef2c8ccb6cd2ba3cff387bd31d9d08b7',1,'kbd_subscribe_int(int *g_hookid_kbd):&#160;kbd.c']]],
  ['kbd_5funsubscribe_5fint',['kbd_unsubscribe_int',['../group__Keyboard.html#gaea06ebd72a5660d2edf7c7b658531762',1,'kbd_unsubscribe_int(int *g_hookid_kbd):&#160;kbd.c'],['../group__Keyboard.html#gaea06ebd72a5660d2edf7c7b658531762',1,'kbd_unsubscribe_int(int *g_hookid_kbd):&#160;kbd.c']]]
];
