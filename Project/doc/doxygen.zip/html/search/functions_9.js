var searchData=
[
  ['read_5fwords',['read_words',['../game_8c.html#a98d45a00c126dd0eab90e945b6466a97',1,'read_words(size_t *n_words):&#160;game.c'],['../group__Game.html#ga4ccad5fef8130fcdcf5f9667725f5ea2',1,'read_words():&#160;game.h']]],
  ['readoutbuffer',['readOutBuffer',['../group__Keyboard.html#ga4fd77adc2d7e8fd3c4646d717e87b67c',1,'readOutBuffer(unsigned long *scancode):&#160;kbd.c'],['../group__Keyboard.html#ga4fd77adc2d7e8fd3c4646d717e87b67c',1,'readOutBuffer(unsigned long *scancode):&#160;kbd.c']]],
  ['readstatusregister',['readStatusRegister',['../group__Keyboard.html#ga409088cbc9c14a22f0527248d3a7066d',1,'readStatusRegister(unsigned long *status):&#160;kbd.c'],['../group__Keyboard.html#ga409088cbc9c14a22f0527248d3a7066d',1,'readStatusRegister(unsigned long *status):&#160;kbd.c']]],
  ['rtc_5fdate',['rtc_date',['../group__RTC.html#gadcc01e49bf3c7c62b7f1887065ba80a7',1,'rtc_date(unsigned long *day, unsigned long *month, unsigned long *year):&#160;rtc.c'],['../group__RTC.html#gadcc01e49bf3c7c62b7f1887065ba80a7',1,'rtc_date(unsigned long *day, unsigned long *month, unsigned long *year):&#160;rtc.c']]],
  ['rtc_5ftime',['rtc_time',['../group__RTC.html#ga0f68badf2d3a45e4154281cf5ae9f79e',1,'rtc_time(unsigned long *sec, unsigned long *min, unsigned long *hour):&#160;rtc.c'],['../group__RTC.html#ga0f68badf2d3a45e4154281cf5ae9f79e',1,'rtc_time(unsigned long *sec, unsigned long *min, unsigned long *hour):&#160;rtc.c']]]
];
