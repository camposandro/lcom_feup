var searchData=
[
  ['update_5fcursor',['update_cursor',['../group__Game.html#ga1e39757b1801a7f7371f88432049cb35',1,'update_cursor(Cursor *cursor, int in_menu):&#160;game.c'],['../group__Game.html#ga1e39757b1801a7f7371f88432049cb35',1,'update_cursor(Cursor *cursor, int in_menu):&#160;game.c']]],
  ['update_5fsnake',['update_snake',['../group__Game.html#gae2901cc7f84aa5b2d537748fc93c2a1f',1,'update_snake(unsigned long scancode):&#160;game.c'],['../group__Game.html#gae2901cc7f84aa5b2d537748fc93c2a1f',1,'update_snake(unsigned long scancode):&#160;game.c']]]
];
