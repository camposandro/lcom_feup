var searchData=
[
  ['write_5fcmd',['write_cmd',['../group__Mouse.html#ga60a5e1ced832c9f0cf63715533577cfc',1,'write_cmd(unsigned long port, unsigned long cmd):&#160;mouse.c'],['../group__Mouse.html#ga60a5e1ced832c9f0cf63715533577cfc',1,'write_cmd(unsigned long port, unsigned long cmd):&#160;mouse.c']]],
  ['write_5fwinner',['write_winner',['../group__Game.html#gaaf73f60e93c678eefb613fbef5dc8bbd',1,'write_winner(int winner):&#160;game.c'],['../group__Game.html#gaaf73f60e93c678eefb613fbef5dc8bbd',1,'write_winner(int winner):&#160;game.c']]]
];
