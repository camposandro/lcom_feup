var searchData=
[
  ['coord_5ft',['coord_t',['../group__Game.html#ga437098a5ab89e0e83c986d7be2a3ca4f',1,'game.h']]],
  ['cursor',['Cursor',['../group__Game.html#gac7c9687307ea23b41e53083470448580',1,'game.h']]]
];
