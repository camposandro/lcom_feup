var searchData=
[
  ['color',['color',['../structSnake.html#a5e850aff3ef56c4e5c100bab14128159',1,'Snake']]],
  ['coord',['coord',['../structCursor.html#a49d8817a50cbd157c5d23b1447f77dd9',1,'Cursor::coord()'],['../structSnake.html#a00fefcc16a255f05ae59a63f2c30b0b6',1,'Snake::coord()']]],
  ['coord_5fkbd',['coord_kbd',['../structWord.html#a5e5828800957d6c9080ae77c12189626',1,'Word']]],
  ['coord_5fmouse',['coord_mouse',['../structWord.html#a850023044f54380e85ae45bb0d00cdda',1,'Word']]],
  ['current_5fbackground',['current_background',['../structMenu.html#ad151a12bee66177321512f2a8f8f39a0',1,'Menu']]],
  ['current_5fstate',['current_state',['../structGame.html#a6888947fb29f84c9f07f6a5c5598345d',1,'Game']]],
  ['cursor',['cursor',['../structGame.html#a8b78c9e4ad2d603ec2c57404def327fd',1,'Game']]],
  ['cursor_5fvictory',['cursor_victory',['../structMenu.html#ae0d6ba943775a3166dc095afaddc4389',1,'Menu']]]
];
