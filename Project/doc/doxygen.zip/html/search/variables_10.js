var searchData=
[
  ['virtual',['virtual',['../group__lmlib.html#ga4de93144fb3ffbceb9bd1f3009d6d98c',1,'mmap_t']]]
];
