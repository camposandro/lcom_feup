var searchData=
[
  ['x',['x',['../structcoord__t.html#a080c2dfe195dae7be02cce3d6b026f25',1,'coord_t']]],
  ['xcharsize',['XCharSize',['../struct____attribute____.html#acac41a300563737d7849a92cd1d5c10b',1,'__attribute__']]],
  ['xresolution',['XResolution',['../struct____attribute____.html#abe48e2b29aa99e813a1447d22711f4f4',1,'__attribute__']]]
];
