var searchData=
[
  ['directcolormodeinfo',['DirectColorModeInfo',['../struct____attribute____.html#a35fb3e1fc0dc9924bc52977b3a234f9f',1,'__attribute__']]]
];
