var searchData=
[
  ['image',['image',['../structCursor.html#ac3f133f7258e3e2737c65d90803754b1',1,'Cursor']]]
];
