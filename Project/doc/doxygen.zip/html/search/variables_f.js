var searchData=
[
  ['side',['side',['../structSnake.html#aeaafc684702ca5b50c9d9b318ac2a7c7',1,'Snake']]],
  ['size',['size',['../group__lmlib.html#gaf1cdc5384a402fddf33f400a5e1e5e45',1,'mmap_t']]],
  ['skip',['skip',['../structstbi__io__callbacks.html#a257aac5480a90a6c4b8fbe86c1b01068',1,'stbi_io_callbacks']]],
  ['snake',['snake',['../structGame.html#ac6002315e7c8ba1da4fe7a763fe442b2',1,'Game']]],
  ['snake_5fvictory',['snake_victory',['../structMenu.html#a4fb32f54c7d82d1cd34131f68c75fb3d',1,'Menu']]],
  ['status',['status',['../game_8c.html#a9c2e24094c936ef0862eb44b30afedf2',1,'game.c']]]
];
